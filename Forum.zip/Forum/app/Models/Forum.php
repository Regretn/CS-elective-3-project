<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Comment;

class Forum extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $fillable =
    [
        'user_id',
        'forum_title',
        'forum_content',
    ];
    public function user()
    {
        return $this->hasMany(User::class, 'id', 'user_id');
    }
    public function comments()
    {
        return $this->hasMany(Comment::class, 'id');
    }
    public function categories()
    {
        return $this->hasMany(Category::class, 'category_id', 'category_id');
    }
}
