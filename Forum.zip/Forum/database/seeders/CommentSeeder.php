<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class CommentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $comment =
            [
                [
                    'id' => '1',
                    'comment_content' => 'Hello',
                    'user_id' => '1',
                ],
                [
                    'id' => '1',
                    'comment_content' => 'Hi',
                    'user_id' => '2',
                ],
                [
                    'id' => '2',
                    'comment_content' => 'Wow',
                    'user_id' => '3',
                ], [
                    'id' => '3',
                    'comment_content' => 'Nice',
                    'user_id' => '4',
                ],
                [
                    'id' => '3',
                    'comment_content' => 'Nice',
                    'user_id' => '5',
                ],
                [
                    'id' => '4',
                    'comment_content' => 'Hello',
                    'user_id' => '6',
                ],
                [
                    'id' => '5',
                    'comment_content' => 'Oh no',
                    'user_id' => '7',
                ],
                [
                    'id' => '6',
                    'comment_content' => 'lorem',
                    'user_id' => '8',
                ],
            ];
        DB::table('comments')->insert($comment);
    }
}
