<?php

namespace Database\Seeders;


use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $category = [
            [
                'category_id' => '1',
                'category_name' => 'Funny',
            ],
            [
                'category_id' => '2',
                'category_name' => 'Scary',
            ],
            [
                'category_id' => '3',
                'category_name' => 'Sports',
            ],
            [
                'category_id' => '4',
                'category_name' => 'Politics',
            ],
            [
                'category_id' => '5',
                'category_name' => 'School',
            ],
            [
                'category_id' => '6',
                'category_name' => 'Social',
            ]
        ];
        DB::table('categories')->insert($category);
    }
}
