<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class ForumSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $forum =
            [
                [
                    'id' => '1',
                    'forum_title' => 'Hello',
                    'forum_content' => 'Good morning',
                    'user_id' => '1',
                    'category_id' => '1'
                ],
                [
                    'id' => '2',
                    'forum_title' => 'Wowww',
                    'forum_content' => 'ohhhhh',
                    'user_id' => '2',
                    'category_id' => '2'
                ],
                [
                    'id' => '3',
                    'forum_title' => 'Ohs',
                    'forum_content' => 'Lorem',
                    'user_id' => '3',
                    'category_id' => '3'
                ], [
                    'id' => '4',
                    'forum_title' => 'Hello',
                    'forum_content' => 'Good morning',
                    'user_id' => '4',
                    'category_id' => '4'
                ], [
                    'id' => '5',
                    'forum_title' => 'Hello',
                    'forum_content' => 'Good afternoon',
                    'user_id' => '5',
                    'category_id' => '5'
                ], [
                    'id' => '6',
                    'forum_title' => 'Hello',
                    'forum_content' => 'Good evening',
                    'user_id' => '6',
                    'category_id' => '6'
                ]
            ];
        DB::table('forums')->insert($forum);
    }
}
