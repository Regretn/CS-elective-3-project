<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('category', function () {
    return App\Models\Category::all();
});
Route::get('category/{category_id}', function ($category_id) {
    return App\Models\Category::find($category_id);
});
Route::get('forum', function () {
    return App\Models\Forum::all();
});
Route::get('forum/{id}', function ($id) {
    return App\Models\Category::find($id);
});
Route::get('comments', function () {
    return App\Models\Comment::all();
});
Route::get('comments/{id}', function ($id) {
    return App\Models\Comment::find($id);
});
Route::get('users', function () {
    return App\Models\User::all();
});
